const button = document.querySelectorAll(".button")
const operate = document.querySelectorAll(".opr")
const screen = document.getElementById("main");

let string = "";

Array.from(button).forEach((buttons)=>{
  buttons.addEventListener("click",(e)=>{
  
   if(e.target.innerText == "="){
    string = eval(string);
    screen.innerHTML = string;
    console.log("hello")
   }
   else if(e.target.innerText == "CLEAR"){
     string = "";
     screen.innerHTML = string;
   }
  
   else{
 
      string = string + e.target.innerText;
      screen.innerHTML = string;
   }
  })
})